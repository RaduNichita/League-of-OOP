package map;

public enum TerrainType {
    W, L, V, D
}

