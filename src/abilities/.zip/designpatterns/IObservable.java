package designpatterns;

public interface IObservable {

    String notifyObserver();
}
