package designpatterns;

public interface INotification {

    String execute();
}
