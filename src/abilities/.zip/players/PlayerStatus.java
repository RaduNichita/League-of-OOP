package players;

public enum PlayerStatus {
    DEAD, ALIVE
}
