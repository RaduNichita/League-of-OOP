package strategies;

public interface IStrategy {

    void applyStrategy();

}
