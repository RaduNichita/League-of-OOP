// Copyright Nichita Radu, 321CA

package main;


import gameinput.GameEngine;
import gameinput.GameInputLoader;
import gameoutput.GameOutput;

import java.io.FileNotFoundException;

public final class Main {

    private Main() {

    }
    public static void main(final String[] args) throws IllegalAccessException,
            FileNotFoundException {

       GameInputLoader gameInputLoader = new GameInputLoader(args[0], args[1]);
       GameOutput gameOutput = new GameOutput(args[1]);
       GameEngine gameEngine = new GameEngine(gameInputLoader.load(),gameOutput);
       gameEngine.processData();
       gameOutput.writeResults(gameEngine.finalScore());

    }
}
